
__version_info__ = ('6', '19', '1')
__version__ = '.'.join(__version_info__)

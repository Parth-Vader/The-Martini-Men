# pylint: disable=missing-docstring
import collections
isinstance([], collections.Iterable)

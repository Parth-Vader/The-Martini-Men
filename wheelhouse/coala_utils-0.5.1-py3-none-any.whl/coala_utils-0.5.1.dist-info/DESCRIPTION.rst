coala-utils
================

coala-utils holds a collection of useful utilities that are used
mainly by coala and can be used by outside sources as well.



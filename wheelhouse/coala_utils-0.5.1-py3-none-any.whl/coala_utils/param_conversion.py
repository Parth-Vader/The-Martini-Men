def negate(a):
    return not a
